# -*- coding: utf-8 -*-
{
'name': 'Assets Management',
'summary': 'Asset, Assets, Asset Management, Assets Management',
'depends': ['account', 'oi_org_chart'],
'excludes': ['account_asset'],
'description': '''
'''
               '''Assets management
'''
               '''=================
'''
               '''Manage assets owned by a company or a person.
'''
               '''Keeps track of depreciations, and creates corresponding journal entries.
'''
               '''
'''
               '    ',
'website': 'https://www.open-inside.com',
'author': 'Openinside',
'category': 'Accounting',
'version': '16.0.1.3.9',
'license': 'OPL-1',
'sequence': 32,
'demo': [],
'data': ['security/account_asset_security.xml',
          'security/ir.model.access.csv',
          'wizard/asset_depreciation_confirmation_wizard_views.xml',
          'wizard/asset_modify_views.xml',
          'views/account_asset_views.xml',
          'views/account_invoice_views.xml',
          'views/product_views.xml',
          'report/account_asset_report_views.xml',
          'data/account_asset_data.xml'],
'assets': {'web.assets_backend': ['oi_account_asset/static/src/js/*/*.js',
                                   'oi_account_asset/static/src/js/*/*.xml',
                                   'oi_account_asset/static/src/js/*/*.scss']},
'images': ['static/description/cover.png'],
'application': True,
'odoo-apps': True,
'price': 30.0,
'currency': 'USD'
}