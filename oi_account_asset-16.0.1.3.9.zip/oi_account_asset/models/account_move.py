# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import fields, models


class AccountMove(models.Model):
    _inherit = 'account.move'

    asset_depreciation_ids = fields.One2many('account.asset.depreciation.line', 'move_id', string='Assets Depreciation Lines')
    account_analytic_id = fields.Many2one('account.analytic.account')
    
    def button_cancel(self):
        for move in self:
            for line in move.asset_depreciation_ids:
                line.move_posted_check = False
        self.env['account.asset.asset'].sudo().search([('invoice_id', 'in', self.ids)]).write({'active': False})
        return super(AccountMove, self).button_cancel()
    
    def _post(self, soft=True):
        for move in self:
            for depreciation_line in move.asset_depreciation_ids:
                depreciation_line.post_lines_and_close_asset()
            move.invoice_line_ids.asset_create()
        return super(AccountMove, self)._post(soft = soft)

    def unlink(self):
        depreciation_line_ids = self.env['account.asset.depreciation.line'].search([('move_id','in', self.ids)])
        
        res = super(AccountMove, self).unlink()
        
        self.env.add_to_compute(depreciation_line_ids._fields['move_check'], depreciation_line_ids)
        
        return res