'''
Created on Oct 31, 2019

@author: Zuhair Hammadi
'''
from odoo import models, fields, api, _
from odoo.exceptions import UserError
from odoo.tools import DEFAULT_SERVER_DATE_FORMAT as DF
from dateutil.relativedelta import relativedelta

def strptime(value, dateformat):  # @UnusedVariable
    return fields.Datetime.to_datetime(value)

class AccountMove(models.Model):
    _inherit = 'account.move.line'
    
    asset_category_id = fields.Many2one(related='product_id.asset_category_id', string='Asset Category')
    deferred_category_id = fields.Many2one(related='product_id.deferred_revenue_category_id', string='Deferred Revenue Type', readonly = False)
    asset_start_date = fields.Date(string='Asset Start Date', compute='_get_asset_date', readonly=True, store=True)
    asset_end_date = fields.Date(string='Asset End Date', compute='_get_asset_date', readonly=True, store=True)
    asset_mrr = fields.Float(string='Monthly Recurring Revenue', compute='_get_asset_date', readonly=True, digits='Account', store=True)
    
    asset_id = fields.Many2one('account.asset.asset')
    
    def _get_asset_amount(self):
        if self.env['ir.config_parameter'].sudo().get_param('asset_value_with_tax') == 'True':
            move_date = self.move_id.date or fields.Date.context_today(self)
            return self.currency_id._convert(self.price_total, self.company_currency_id, self.company_id, move_date)
        else:
            return self.balance    

    @api.depends('asset_category_id', 'move_id.invoice_date')
    def _get_asset_date(self):
        for record in self:
            record.asset_mrr = 0
            record.asset_start_date = False
            record.asset_end_date = False
            cat = record.asset_category_id
            if cat:
                if cat.method_number == 0 or cat.method_period == 0:
                    raise UserError(_('The number of depreciations or the period length of your asset category cannot be null.'))
                months = cat.method_number * cat.method_period
                if record.move_id.move_type in ['out_invoice', 'out_refund']:
                    record.asset_mrr = record.balance / months
                if record.move_id.invoice_date:
                    start_date = strptime(record.move_id.invoice_date, DF).replace(day=1)
                    end_date = (start_date + relativedelta(months=months, days=-1))
                    record.asset_start_date = start_date.strftime(DF)
                    record.asset_end_date = end_date.strftime(DF)
                    
    
    def _asset_create(self, number = None, price = None):
        self.ensure_one()
        asset_category_id = self.asset_category_id or self.deferred_category_id
        vals = {
            'name': "%s%s" % (self.name , number or ''),
            'code': self.move_id.name or False,
            'category_id': asset_category_id.id,
            'value': price or self._get_asset_amount(),
            'partner_id': self.move_id.partner_id.id,
            'company_id': self.move_id.company_id.id,
            'currency_id': self.move_id.company_currency_id.id,
            'date': self.move_id.invoice_date,
            'invoice_id': self.move_id.id,
            'product_id' : self.product_id.id,
        }
        changed_vals = self.env['account.asset.asset'].onchange_category_id_values(vals['category_id'])
        vals.update(changed_vals['value'])
        asset = self.env['account.asset.asset'].create(vals)
        if self.asset_category_id.open_asset:
            asset.validate()                    
            
    def asset_create(self):
        for record in self:
            asset_category_id = record.deferred_category_id if record.move_id.is_sale_document(True) else record.asset_category_id
            if asset_category_id:
                if asset_category_id.create_multi:
                    quantity = int(record.quantity)
                    remain_amt = record._get_asset_amount()
                    remain_qty = quantity
                    for n in range(quantity):
                        price = record.move_id.company_currency_id.round(remain_amt / remain_qty)
                        record._asset_create(n + 1, price)
                        remain_amt -=price
                        remain_qty -=1
                else:
                    record._asset_create()                
        return True 
    

    @api.onchange('asset_category_id')
    def onchange_asset_category_id(self):
        if self.move_id.move_type in ['out_invoice','out_receipt'] and self.asset_category_id:
            self.account_id = self.asset_category_id.account_asset_id.id
        elif self.move_id.move_type in ['in_invoice','in_receipt'] and self.asset_category_id:
            self.account_id = self.asset_category_id.account_asset_id.id
        
    @api.onchange('product_id')
    def _onchange_product_id(self):        
        if self.product_id:
            if self.move_id.move_type in ['out_invoice','out_receipt']:
                self.asset_category_id = self.product_id.deferred_revenue_category_id
            elif self.move_id.move_type in ['in_invoice','in_receipt']:
                self.asset_category_id = self.product_id.asset_category_id
                


