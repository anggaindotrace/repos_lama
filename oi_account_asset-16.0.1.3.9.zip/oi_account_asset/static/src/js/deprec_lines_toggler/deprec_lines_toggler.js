/** @odoo-module **/

import { registry } from "@web/core/registry";
import { _lt } from "@web/core/l10n/translation";
import { BooleanField } from "@web/views/fields/boolean/boolean_field";
import { useService } from "@web/core/utils/hooks";

const { onWillUpdateProps } = owl;

export class AssetDeprecField extends BooleanField {
    
    setup() {
        this.orm = useService("orm");
        this.formatData(this.props);
        onWillUpdateProps((nextProps) => this.formatData(nextProps));        
    }
    
    formatData(props) {
        var className = '';
        var disabled = true;
        var title;
        if (props.record.data.move_posted_check) {
            className = 'o_is_posted';
            title = _lt('Posted');
        } else if (props.record.data.move_check) {
            className = 'o_unposted';
            title = _lt('Accounting entries waiting for manual verification');
        } else {
            disabled = false;
            title = _lt('Unposted');
        }
        
        this.className = 'btn btn-sm btn-link fa fa-circle o_deprec_lines_toggler ' + className;
        this.disabled = disabled;	
        this.title = title;
	}
    
        
    async onClick() {
		const args = [
			[this.props.record.data.id]
		];
		await this.orm.call(this.props.record.resModel, 'create_move', args, {});
		await this.props.record.model.root.save();
		await this.props.record.model.root.load();
		await this.props.record.model.root.model.notify();
		
	}
    
}

AssetDeprecField.template = "oi_account_asset.AssetDeprecField";

AssetDeprecField.displayName = _lt("Toggle");

registry.category("fields").add("deprec_lines_toggler", AssetDeprecField);
