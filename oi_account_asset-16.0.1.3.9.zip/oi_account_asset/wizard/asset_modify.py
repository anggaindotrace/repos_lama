# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from lxml import etree

from odoo import api, fields, models, _
from odoo.tools.safe_eval import safe_eval
import json
#from odoo.osv.orm import setup_modifiers

# def transfer_node_to_modifiers(node, modifiers, context=None, in_tree_view=False):
#     if node.get('attrs'):
#         modifiers.update(safe_eval(node.get('attrs')))
#
#     if node.get('states'):
#         if 'invisible' in modifiers and isinstance(modifiers['invisible'], list):
#             # TODO combine with AND or OR, use implicit AND for now.
#             modifiers['invisible'].append(('state', 'not in', node.get('states').split(',')))
#         else:
#             modifiers['invisible'] = [('state', 'not in', node.get('states').split(','))]
#
#     for a in ('invisible', 'readonly', 'required'):
#         if node.get(a):
#             v = bool(safe_eval(node.get(a), {'context': context or {}}))
#             if in_tree_view and a == 'invisible':
#                 # Invisible in a tree view has a specific meaning, make it a
#                 # new key in the modifiers attribute.
#                 modifiers['column_invisible'] = v
#             elif v or (a not in modifiers or not isinstance(modifiers[a], list)):
#                 # Don't set the attribute to False if a dynamic value was
#                 # provided (i.e. a domain from attrs or states).
#                 modifiers[a] = v
#
#
# def simplify_modifiers(modifiers):
#     for a in ('invisible', 'readonly', 'required'):
#         if a in modifiers and not modifiers[a]:
#             del modifiers[a]
#
#
# def transfer_modifiers_to_node(modifiers, node):
#     if modifiers:
#         simplify_modifiers(modifiers)
#         node.set('modifiers', json.dumps(modifiers))
#
#
# def transfer_field_to_modifiers(field, modifiers):
#     default_values = {}
#     state_exceptions = {}
#     for attr in ('invisible', 'readonly', 'required'):
#         state_exceptions[attr] = []
#         default_values[attr] = bool(field.get(attr))
#     for state, modifs in field.get("states",{}).items():
#         for modif in modifs:
#             if default_values[modif[0]] != modif[1]:
#                 state_exceptions[modif[0]].append(state)
#
#     for attr, default_value in default_values.items():
#         if state_exceptions[attr]:
#             modifiers[attr] = [("state", "not in" if default_value else "in", state_exceptions[attr])]
#         else:
#             modifiers[attr] = default_value
#
#
# def setup_modifiers(node, field=None, context=None, in_tree_view=False):
#     """ Processes node attributes and field descriptors to generate
#     the ``modifiers`` node attribute and set it on the provided node.
#
#     Alters its first argument in-place.
#
#     :param node: ``field`` node from an OpenERP view
#     :type node: lxml.etree._Element
#     :param dict field: field descriptor corresponding to the provided node
#     :param dict context: execution context used to evaluate node attributes
#     :param bool in_tree_view: triggers the ``column_invisible`` code
#                               path (separate from ``invisible``): in
#                               tree view there are two levels of
#                               invisibility, cell content (a column is
#                               present but the cell itself is not
#                               displayed) with ``invisible`` and column
#                               invisibility (the whole column is
#                               hidden) with ``column_invisible``.
#     :returns: nothing
#     """
#     modifiers = {}
#     if field is not None:
#         transfer_field_to_modifiers(field, modifiers)
#     transfer_node_to_modifiers(
#         node, modifiers, context=context, in_tree_view=in_tree_view)
#     transfer_modifiers_to_node(modifiers, node)

class AssetModify(models.TransientModel):
    _name = 'asset.modify'
    _description = 'Modify Asset'

    name = fields.Text(string='Reason', required=True)
    method_number = fields.Integer(string='Number of Depreciations', required=True)
    method_period = fields.Integer(string='Period Length')
    method_end = fields.Date(string='Ending date')
    asset_method_time = fields.Char(compute='_get_asset_method_time', string='Asset Method Time', readonly=True)

    def _get_asset_method_time(self):
        for record in self:
            if record.env.context.get('active_id'):
                asset = record.env['account.asset.asset'].browse(record.env.context.get('active_id'))
                record.asset_method_time = asset.method_time

    # @api.model
    # def get_view(self, view_id=None, view_type='form', **options):
    #     result = super(AssetModify, self).get_view(view_id=view_id, view_type=view_type, **options)
    #     asset_id = self.env.context.get('active_id')
    #     active_model = self.env.context.get('active_model')
    #     if active_model == 'account.asset.asset' and asset_id:
    #         asset = self.env['account.asset.asset'].browse(asset_id)
    #         doc = etree.XML(result['arch'])
    #         if asset.method_time == 'number' and doc.xpath("//field[@name='method_end']"):
    #             node = doc.xpath("//field[@name='method_end']")[0]
    #             node.set('invisible', '1')
    #             setup_modifiers(node, result['fields']['method_end'])
    #         elif asset.method_time == 'end' and doc.xpath("//field[@name='method_number']"):
    #             node = doc.xpath("//field[@name='method_number']")[0]
    #             node.set('invisible', '1')
    #             setup_modifiers(node, result['fields']['method_number'])
    #         result['arch'] = etree.tostring(doc, encoding='unicode')
    #     return result

    @api.model
    def default_get(self, fields):
        res = super(AssetModify, self).default_get(fields)
        asset_id = self.env.context.get('active_id')
        asset = self.env['account.asset.asset'].browse(asset_id)
        if 'name' in fields:
            res.update({'name': asset.name})
        if 'method_number' in fields and asset.method_time == 'number':
            res.update({'method_number': asset.method_number})
        if 'method_period' in fields:
            res.update({'method_period': asset.method_period})
        if 'method_end' in fields and asset.method_time == 'end':
            res.update({'method_end': asset.method_end})
        if self.env.context.get('active_id'):
            active_asset = self.env['account.asset.asset'].browse(self.env.context.get('active_id'))
            res['asset_method_time'] = active_asset.method_time
        return res

    def modify(self):
        """ Modifies the duration of asset for calculating depreciation
        and maintains the history of old values, in the chatter.
        """
        asset_id = self.env.context.get('active_id', False)
        asset = self.env['account.asset.asset'].browse(asset_id)
        old_values = {asset.id : {
            'method_number': asset.method_number,
            'method_period': asset.method_period,
            'method_end': asset.method_end,
        }}
        asset_vals = {
            'method_number': self.method_number,
            'method_period': self.method_period,
            'method_end': self.method_end,
        }
        asset.write(asset_vals)
        asset.compute_depreciation_board()
        tracked_fields = self.env['account.asset.asset'].fields_get(['method_number', 'method_period', 'method_end'])
        changes, tracking_value_ids = asset._message_track(tracked_fields, old_values)[asset.id]
        if changes:
            asset.message_post(subject=_('Depreciation board modified'), body=self.name)
        return {'type': 'ir.actions.act_window_close'}
