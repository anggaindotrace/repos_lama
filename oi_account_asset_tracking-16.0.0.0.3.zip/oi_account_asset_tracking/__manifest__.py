# -*- coding: utf-8 -*-
# Copyright 2018 Openinside co. W.L.L.
{
    "name": "Assets Tracking",
    "summary": "Asset, Assets, Asset Management, Assets Management, Asset Tracking, Track, Trace, Trace Asset",
    "version": "16.0.0.0.3",
    'category': 'Accounting',
    "website": "https://www.open-inside.com",
	"description": """
		Assets Tracking
    """,
    "author": "Openinside",
    "license": "OPL-1",
    "price" : 129.99,
    "currency": 'USD',
    "installable": True,
    "depends": [
        'oi_account_asset', 'hr', 'oi_account_asset_use_state', 'oi_workflow', 'purchase_stock', "oi_fields_attribute"
    ],
    "data": [
       'security/res_groups.xml',
       'security/ir.model.access.csv',
       'data/ir_sequence.xml',
       'view/account_asset_asset.xml',
       'view/account_asset_location.xml',
       'view/account_asset_movement.xml',
       'view/account_asset_category.xml',
       'view/product_template.xml',       
       'view/hr_employee.xml',
       'view/account_asset_attribute.xml',
       'view/action.xml',
       'view/menu.xml',
       'view/stock_warehouse.xml'
    ],
    'images': [
        'static/description/cover.png'
    ],
    'application' : True,
    'installable': True,
    'odoo-apps' : True     
}

