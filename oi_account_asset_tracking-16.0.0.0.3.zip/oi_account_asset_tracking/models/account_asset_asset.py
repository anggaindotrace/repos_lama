'''
Created on Jul 29, 2019

@author: Zuhair Hammadi
'''
from odoo import models, fields, api

class Asset(models.Model):
    _inherit = 'account.asset.asset'
    
    movement_ids = fields.One2many('account.asset.movement','asset_id', domain = [('state','=', 'approved')])
    movement_count = fields.Integer(compute = '_calc_movement_count')
    
    movement_id = fields.Many2one('account.asset.movement',string='Last Movement', compute = '_calc_current', store = True, compute_sudo = True)
    location_id = fields.Many2one('account.asset.location', compute = '_calc_current', store = True, compute_sudo = True)
    employee_id = fields.Many2one('hr.employee', compute = '_calc_current', store = True, compute_sudo = True)
    department_id = fields.Many2one('hr.department', compute = '_calc_current', store = True, compute_sudo = True)
    product_tmpl_id = fields.Many2one(related='product_id.product_tmpl_id', store = True)
    
    image_1920 = fields.Image(related='product_id.image_1920', readonly = True)
    image_1024 = fields.Image(related='product_id.image_1024', readonly = True)
    image_512 = fields.Image(related='product_id.image_512', readonly = True)
    image_256 = fields.Image(related='product_id.image_256', readonly = True)
    image_128 = fields.Image(related='product_id.image_128', readonly = True)    
        
    @api.depends('movement_ids.state')
    def _calc_current(self):
        for record in self:
            last_movement = record.movement_ids[:1]
            if last_movement:
                for fname in ['location_id', 'employee_id', 'department_id']:
                    record[fname] = last_movement[fname]            
                record.movement_id = last_movement
            else:
                for fname in ['location_id', 'employee_id', 'department_id', 'movement_id']:
                    record[fname] = False
    
    @api.depends('movement_ids')
    def _calc_movement_count(self):
        for record in self:
            record.movement_count = len(record.movement_ids)
    
    def action_movement(self):
        action, = self.env.ref('oi_account_asset_tracking.act_asset_movement').read()
        action['domain'] = [('asset_id','=', self.id)]
        action['context'] = {'default_asset_id' : self.id}
        return action
    
    
    @api.model_create_multi
    @api.returns('self', lambda value:value.id)
    def create(self, vals_list):
        if self.env["ir.sequence"].search([("code","=", self._name)]):
            for vals in vals_list:
                if not vals.get("code"):
                    vals["code"] = self.env["ir.sequence"].next_by_code(self._name)
        return super(models.Model, self).create(vals_list)