'''
Created on Jul 30, 2019

@author: Zuhair Hammadi
'''
from odoo import models, fields

class AccountAssetCategory(models.Model):
    _inherit = 'account.asset.category'
    
    create_multi = fields.Boolean('Create record for each quantity')
    auto_create = fields.Selection([('invoice', 'Invoice'), ('stock', 'Material Receipts')], default = 'invoice', string='Automatic Creation')