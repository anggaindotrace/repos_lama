'''
Created on Jul 30, 2019

@author: Zuhair Hammadi
'''
from odoo import models, api

class AccountMoveLine(models.Model):
    _inherit = 'account.move.line'
    
    
    def _asset_create(self, number = None, price = None):
        self.ensure_one()
        asset_category_id = self.asset_category_id or self.deferred_category_id
        vals = {
            'name': "%s%s" % (self.name , number or ''),
            'code': self.move_id.name or False,
            'category_id': asset_category_id.id,
            'value': price or self._get_asset_amount(),
            'partner_id': self.move_id.partner_id.id,
            'company_id': self.move_id.company_id.id,
            'currency_id': self.move_id.company_currency_id.id,
            'date': self.move_id.invoice_date,
            'invoice_id': self.move_id.id,
            'product_id' : self.product_id.id,
        }
        changed_vals = self.env['account.asset.asset'].onchange_category_id_values(vals['category_id'])
        vals.update(changed_vals['value'])
        asset = self.env['account.asset.asset'].create(vals)
        if self.asset_category_id.open_asset:
            asset.validate()

    
    
    def asset_create(self):
        for record in self:
            asset_category_id = record.deferred_category_id if record.move_id.is_sale_document(True) else record.asset_category_id
            if asset_category_id.auto_create == 'invoice':
                if asset_category_id.create_multi:
                    quantity = int(record.quantity)
                    remain_amt = record._get_asset_amount()
                    remain_qty = quantity
                    for n in range(quantity):
                        price = record.move_id.company_currency_id.round(remain_amt / remain_qty)
                        record._asset_create(n + 1, price)
                        remain_amt -=price
                        remain_qty -=1
                else:
                    record._asset_create()                
        return True
        