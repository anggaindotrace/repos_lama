'''
Created on Nov 20, 2019

@author: Zuhair Hammadi
'''
from odoo import models, fields, api, _

class StockMove(models.Model):
    _inherit = 'stock.move'    
    
    def _get_asset_amount(self):
        if self.env['ir.config_parameter'].sudo().get_param('asset_value_with_tax') == 'True':
            purchase_date = self.purchase_line_id.date_order or fields.Date.context_today(self)
            return self.company_id.currency_id._convert(self.purchase_line_id.price_total, self.purchase_line_id.currency_id, self.purchase_line_id.company_id, purchase_date)
        else:
            return self.purchase_line_id.price_subtotal
    
    def _asset_create(self, number = None, price = None):
        self.ensure_one()
        asset_category_id = self.purchase_line_id.product_id.asset_category_id
        vals = {
            'name': ' '.join(filter(None, [self.purchase_line_id.name or self.product_id.name or ''])),
            'code': False,
            'category_id': asset_category_id.id,
            'value': price or 0,
            'partner_id': self.purchase_line_id.order_id.partner_id.id,
            'company_id': self.company_id.id,
            'currency_id': self.company_id.currency_id.id,
            'date': self.picking_id.scheduled_date or self.date,
            'invoice_id': False,
            'product_id' : self.product_id.id,
        }
        changed_vals = self.env['account.asset.asset'].onchange_category_id_values(vals['category_id'])
        vals.update(changed_vals['value'])
        asset = self.env['account.asset.asset'].create(vals)
        if asset_category_id.open_asset:
            asset.validate()
        
        # create asset movement
        warehouse_id = self.location_dest_id.get_warehouse()
        if warehouse_id and warehouse_id.asset_location_id :
            movement_id = self.env['account.asset.movement'].create({
                'asset_id': asset.id,
                'location_id': warehouse_id.asset_location_id.id,
            })
            movement_id.action_approve()
    
    def _action_done(self, cancel_backorder = False):
        res = super(StockMove, self)._action_done(cancel_backorder=self.env.context.get('cancel_backorder'))
        
        for record in self:
            asset_category_id = record.sudo().purchase_line_id.product_id.asset_category_id
            if asset_category_id.auto_create == 'stock' and record.state=='done' and record.quantity_done > 0 and record.picking_id.picking_type_id.code=='incoming':                
                currency_id = record.company_id.currency_id
                price_subtotal = record._get_asset_amount() * (record.quantity_done / record.product_uom_qty)
                
                if record.purchase_line_id.currency_id != currency_id:
                    price_subtotal = record.purchase_line_id.currency_id._convert(price_subtotal, currency_id, record.company_id, record.date)
                    
                if asset_category_id.create_multi:
                    quantity = int(record.quantity_done)
                    remain_amt = price_subtotal
                    remain_qty = quantity
                    for n in range(quantity):
                        price = currency_id.round(remain_amt / remain_qty)
                        record._asset_create(n + 1, price)
                        remain_amt -=price
                        remain_qty -=1
                else:
                    record.sudo()._asset_create(price = price_subtotal)                
                    
        return res