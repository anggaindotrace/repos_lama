# -*- coding: utf-8 -*-
# Copyright 2018 Openinside co. W.L.L.
{
    "name": "Asset Use Status",
    "summary": "Asset Report, Asset, Asset Dashboard, Depreciation, Asset, Assets, Asset Management, Assets Management",
    "version": "16.0.0.0.0",
    'category': 'Accounting',
    "website": "https://www.open-inside.com",
	"description": """
		Asset Use Status 
    """,
    'images': [
        'static/description/cover.png'
    ],
    "author": "Openinside",
    "license": "OPL-1",
    "price" : 9.99,
    "currency": 'USD',
    "installable": True,
    "depends": [
        'oi_account_asset'
    ],
    "data": [
       'view/action.xml',
       'view/account_asset_asset.xml',
       'view/account_asset_use_state.xml',
       'view/account_asset_dispose_wizard.xml',       
       'view/menu.xml',
       'security/ir.model.access.csv',
       'data/account_asset_use_state.xml'
    ],
    'installable': True,
    'odoo-apps' : True,
    'post_init_hook' : 'post_init_hook'    
}

