'''
Created on Jan 3, 2017

@author: zuhair
'''
from odoo import models, fields, api, _
from odoo.exceptions import UserError

class AccountAssetAsset(models.Model):
    _inherit = 'account.asset.asset'
    
    @api.model
    def _get_use_state_id(self):
        return self.env['account.asset.use.state'].search([], limit = 1)
    
    @api.model
    def get_use_state_value(self):
        return [(state.value, state.name) for state in self.env['account.asset.use.state'].search([])]
        
    use_state_id = fields.Many2one('account.asset.use.state', 
                                 string='Use Status',
                                 default=_get_use_state_id, 
                                 copy=False, 
                                 tracking=True)

    use_state_value = fields.Selection(get_use_state_value, compute = '_calc_use_state_value')
    
    @api.depends('use_state_id.value')
    def _calc_use_state_value(self):
        for record in self:
            record.use_state_value = record.use_state_id.value
            
            
    def write(self, vals):
        if 'use_state_id' in vals:
            for record in self:
                if record.state == 'close':
                    raise UserError(_('Asset Closed'))
        return super(AccountAssetAsset, self).write(vals)