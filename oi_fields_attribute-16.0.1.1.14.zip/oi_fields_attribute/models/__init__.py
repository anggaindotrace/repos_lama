from . import ir_model_fields_attribute
from . import ir_model_fields
from . import ir_ui_view