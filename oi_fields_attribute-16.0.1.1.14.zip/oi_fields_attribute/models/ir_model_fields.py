'''
Created on Feb 24, 2019

@author: Zuhair Hammadi
'''
from odoo import models, fields, api, tools

from _collections import deque

class IrModelFields(models.Model):
    _inherit = 'ir.model.fields'
    
    attribute_count = fields.Integer(compute = '_calc_attribute_count')
    
    def _calc_attribute_count(self):
        for record in self:
            record.attribute_count = self.env['ir.model.fields.attribute'].search([('field_id','=', record.id)], count = True)
    
    def action_attributes(self):                                                                 
        return {
            'type' : 'ir.actions.act_window',
            'name': 'Attributes',
            'res_model' : 'ir.model.fields.attribute',
            'domain' : [('field_id','=', self.id)],
            'view_mode' : 'tree,form',
            'views' : [(False, 'tree'), (False, 'form')],
            'context' : {
                'default_field_id' : self.id
                }
            }
                                
    @api.model
    def _update_registry(self):
        assert self.env.user._is_system()
        self.env.flush_all()
        
        self.clear_caches()       
        self.env['ir.model.fields.attribute'].clear_caches()                    
        self.env.reset()
               
        self.pool.registry_invalidated = True                                   
        self.pool.setup_models(self._cr)
        # reload the client;
        return {
            'type': 'ir.actions.client',
            'tag': 'reload'
        }        

    def _update_db(self):
        for record in self:
            self.env.registry._post_init_queue =  deque()
            model = self.env[record.model]
            columns = tools.table_columns(self.env.cr, model._table)
            field = model._fields[record.name]
            field.update_db(model, columns)
            while self.env.registry._post_init_queue:
                func = self.env.registry._post_init_queue.popleft()
                func()            
            del self.env.registry._post_init_queue
            
    def _set_attribute(self, attribute, value):
        self.ensure_one()
        self.env['ir.model.fields.attribute'].with_context(active_test = False).search([('field_id', '=', self.id), ('attribute','=', attribute)]).unlink()
        if value is not None:
            self.env['ir.model.fields.attribute'].create({
                'field_id' : self.id,
                'attribute' : attribute,
                'value' : value
                })
            
    def write(self, vals):
        if vals == {'translate': True} and len(self) ==1 and self.state != 'manual':
            self._set_attribute('translate', True)
            return self._write(vals)
        
        if vals == {'translate': False} and len(self) ==1 and self.state != 'manual':
            self._set_attribute('translate', None)
            return self._write(vals)        
        
        return super(IrModelFields, self).write(vals)
        
            