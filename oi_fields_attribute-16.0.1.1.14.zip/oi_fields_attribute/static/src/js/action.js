odoo.define('oi_fields_attribute.action', function (require) {
"use strict";

var core = require('web.core');
var session = require('web.session');
var Dialog = require('web.Dialog');
var _t = core._t;
var qweb = core.qweb;

var FieldsAttribute = function (parent, action) {
	
	var self = parent;

	session.rpc('/oi_fields_attribute/info', {field_id : action.context.active_id, context : action.context}).then(function (data){
		var buttons = [
        	{
        		text: _t("Ok"), 
        		close: true,
        		classes: 'btn-primary',
        	}
        ];
        		        				
		new Dialog(self, {
            title: _t("Field Attributes"),
            size: 'large',
            buttons : buttons,
            $content: qweb.render('oi_fields_attribute.attrs', {
            	data : data,
            })
        }).open();
	});
	
	return {
    	type : 'ir.actions.act_window_close'
    }
}

var DatabaseFieldsAttribute = function (parent, action) {

	var self = parent;

	session.rpc('/oi_fields_attribute/database_info', {field_id : action.context.active_id, context : action.context}).then(function (data){
		var buttons = [
        	{
        		text: _t("Ok"), 
        		close: true,
        		classes: 'btn-primary',
        	}
        ];
        		        				
		new Dialog(self, {
            title: _t("Field Attributes"),
            size: 'large',
            buttons : buttons,
            $content: qweb.render('oi_fields_attribute.attrs', {
            	data : data,
            })
        }).open();
	});
	
	return {
    	type : 'ir.actions.act_window_close'
    }
}


core.action_registry.add('field_attributes', FieldsAttribute);
core.action_registry.add('field_database_attributes', DatabaseFieldsAttribute);

});