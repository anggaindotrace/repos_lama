from . import ir_model_fields
from . import ir_model_fields_selection_custom
from . import fields
from . import ir_model_fields_selection