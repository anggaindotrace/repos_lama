from . import mail_mail
from . import mail_template
from . import res_users
from . import ir_model
from . import mail_message