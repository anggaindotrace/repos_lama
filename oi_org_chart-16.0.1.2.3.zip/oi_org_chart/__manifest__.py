# -*- coding: utf-8 -*-
{
'name': 'Organization Chart Widget',
'summary': 'Organization Chart Widget to be used in any parent/child model, '
           'Organization, Chart, Widget, Hierarchy, Hierarchical Chart, Model Structure, '
           'one2many field widget, Multi-level',
'category': 'Extra Tools',
'website': 'https://www.open-inside.com',
'author': 'Openinside',
'version': '16.0.1.2.3',
'license': 'OPL-1',
'price': 68.0,
'currency': 'USD',
'installable': True,
'application': False,
'depends': ['hr_org_chart'],
'data': [],
'assets': {'web.assets_backend': ['oi_org_chart/static/src/js/org_chart.js',
                                   'oi_org_chart/static/src/xml/org_chart.xml']},
'odoo-apps': True,
'auto_install': True,
'images': ['static/description/cover.png'],
'description': False
}