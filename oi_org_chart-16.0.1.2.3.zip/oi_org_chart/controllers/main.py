'''
Created on Apr 19, 2018

@author: Zuhair Hammadi
'''

from odoo import http
from odoo.exceptions import AccessError
from odoo.http import request

class OrgChartController(http.Controller):
    
    def _get_record(self, record_id,model):
        if not record_id or not model:
            return
        model = request.env.get(model)  # @UndefinedVariable
        if model is None:
            return
        record = model.browse(record_id)
        if not record.exists():
            return
        try:
            record.check_access_rights('read')
            record.check_access_rule('read')
        except AccessError:
            return
        
        return record
    
    def _get_subordinate(self, record, field):
        direct_child_ids = child_ids = record[field.name]
        indirect_child_ids = record[field.name].browse()
         
        while child_ids:
            child_ids = child_ids[field.name]
            indirect_child_ids += child_ids
            
        return direct_child_ids, indirect_child_ids
                                    
        
    
    def _prepare_record_data(self, record, field, rec_name, is_self = False):
        direct_child_ids, indirect_child_ids = self._get_subordinate(record, field)
                
        return {
            'id' : record.id,
            'name' : record[rec_name],
            'link': f"/mail/view?model={record._name}&res_id={record.id}",
            'direct_sub_count' : len(direct_child_ids),
            'indirect_sub_count': len(direct_child_ids) + len(indirect_child_ids),
            'model' : record._name,
            'is_self' : is_self,
            'field_name' : field.name,
            'inverse_name' : field.inverse_name,
            'style' : record._org_chart_style()
            }

    @http.route('/org_chart/get_org_chart', type='json', auth='user')
    def get_org_chart(self, record_id,model,fieldname, rec_name, **kw):
        record = self._get_record(record_id, model)
        field = record._fields[fieldname]
        res = {
                'parents': [],
                'children': [],
            }
        rec_name = rec_name or 'display_name'
        if not record or field.type !='one2many':
            return res
        
        _parents_level = record._org_chart_parents_level()
                
        # compute record data for org chart
        ancestors, current = record.browse(), record
        
        inverse_name = field.inverse_name
        if not inverse_name and field.related:
            field_related = record._fields[field.related]
            inverse_name = field_related.inverse_name
        
        while current[inverse_name] and len(ancestors) < _parents_level+1:
            current = current[inverse_name]
            ancestors += current
        
        res.update({
            'self' : self._prepare_record_data(record, field, rec_name, is_self = True),
            'parents' : [
                self._prepare_record_data(ancestor, field, rec_name)
                for idx, ancestor in enumerate(ancestors)
                if idx < _parents_level
                ],
            'parents_more': len(ancestors) > _parents_level,
            'children' : [self._prepare_record_data(child, field, rec_name) for child in record[fieldname]]
            })
        
        res['parents'].reverse()
        
        return res        
        
        
    @http.route('/org_chart/get_subordinates', type='json', auth='user')
    def get_subordinates(self, record_id, model, fieldname, subordinates_type=None, **kw):
        record = self._get_record(record_id, model)
        field = record._fields[fieldname]
        if not record:
            return []
        
        direct_child_ids, indirect_child_ids = self._get_subordinate(record, field)
        
        if subordinates_type == 'direct':
            res = direct_child_ids.ids
        elif subordinates_type == 'indirect':                        
            res = indirect_child_ids.ids
        else:
            res = (direct_child_ids + indirect_child_ids).ids
            
        return res
        

    def _prepare_employee_data(self, record):   
        link = '#id=%d&view_type=form&model=%s&action=%d' % (record.id, record._name, record._default_action())
        return dict(
            id=record.id,
            name=record.display_name,
            link= link,
            job_id=False,
            job_name='',
            direct_sub_count=len(record.child_ids),
            indirect_sub_count='child_all_count' in record and record.child_all_count or 0,
            background = record._org_chart_background()
        )

    #@http.route('/org_chart/get_org_chart', type='json', auth='user')
    def get_org_chart1(self, res_id, res_model):        
        if not res_id or not res_model:  # to check
            return {}
        res_id = int(res_id)
        
        Model = request.env[res_model].with_context(hierarchical_naming = False)
        # check and raise
        if not Model.check_access_rights('read', raise_exception=False):
            return {}
        try:
            Model.browse(res_id).check_access_rule('read')
        except AccessError:
            return {}
        else:
            record = Model.browse(res_id)

        # compute record data for org chart
        ancestors = []
        current= record
        while current.parent_id:
            ancestors.append(current.parent_id)
            current = current.parent_id
        
        _managers_level = record._managers_level()
        
        values = dict(
            self=self._prepare_employee_data(record),
            managers=[self._prepare_employee_data(ancestor) for idx, ancestor in enumerate(ancestors) if idx < _managers_level],
            managers_more=len(ancestors) > _managers_level,
            children=[self._prepare_employee_data(child) for child in record.child_ids],
            popover = record._orgchart_popover()
        )
        values['managers'].reverse()
        return values
