'''
Created on May 13, 2018

@author: Zuhair Hammadi
'''
from odoo import models

class Base(models.AbstractModel):
    _inherit = 'base'
        
    def _org_chart_parents_level(self):
        return 5
    
    def _org_chart_style(self):
        return 'background-color : #cccccc'