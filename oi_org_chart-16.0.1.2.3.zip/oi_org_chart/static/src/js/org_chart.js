/** @odoo-module */

import {Field} from '@web/views/fields/field';
import { registry } from "@web/core/registry";
import { useService } from "@web/core/utils/hooks";
import { usePopover } from "@web/core/popover/popover_hook";

const { Component, onWillStart, onWillRender, useState } = owl;

function useUniquePopover() {
    const popover = usePopover();
    let remove = null;
    return Object.assign(Object.create(popover), {
        add(target, component, props, options) {
            if (remove) {
                remove();
            }
            remove = popover.add(target, component, props, options);
            return () => {
                remove();
                remove = null;
            };
        },
    });
}

class OrgChartPopover extends Component {
    async setup() {
        super.setup();

        this.rpc = useService('rpc');
        this.orm = useService('orm');
        this.actionService = useService("action");
    }

    /**
     * Get subordonates of an record through a rpc call.
     *
     * @private
     * @param {integer} record_id
     * @returns {Promise}
     */
    async _getSubordinatesData(record_id, type) {
        const subData = await this.rpc(
            '/org_chart/get_subordinates',
            {
                record_id: record_id,                
                model: this.props.record.model,
                fieldname: this.props.record.field_name,
                subordinates_type: type,
                context: this.props.context,
            }
        );
        return subData;
    }

    /**
     * Redirect to the record form view.
     *
     * @private
     * @param {MouseEvent} event
     * @returns {Promise} action loaded
     */
    async _onRecordRedirect(recordId, model, context) {
        const action = await this.orm.call(model, 'get_formview_action', [recordId], {context: context});
        this.actionService.doAction(action, {clearBreadcrumbs : this.props.clearBreadcrumbs}); 
    }

    /**
     * Redirect to the sub record form view.
     *
     * @private
     * @param {MouseEvent} event
     * @returns {Promise} action loaded
     */
    async _onRecordSubRedirect(event) {
        const record_id = parseInt(event.currentTarget.dataset.recordId);
        const type = event.currentTarget.dataset.type || 'direct';
        
        if (!record_id ) {
            return {};
        }
        
        const model = this.props.record.model;
        const subData = await this._getSubordinatesData(record_id, type);
        const domain = [['id', 'in', subData]];                
        
        var action = await this.orm.call(model, 'get_formview_action', [record_id]);
        var context = _.extend({}, this.props.context);
        context[`default_${this.props.record.inverse_name}`] = record_id;

        action = Object.assign(action, {
            'name': this.env._t('Subordinates'),
            'view_mode': 'list,form',
            'views':  [[false, 'list'], [false, 'form']],
            'domain': domain,
            'context': context
        });
        delete action['res_id'];
        this.actionService.doAction(action);
    }
}
OrgChartPopover.template = 'org_chart.orgchart_record_popover';

export class OrgChart extends Field {
    async setup() {
        super.setup();

        this.rpc = useService('rpc');
        this.orm = useService('orm');
        this.actionService = useService("action");
        this.popover = useUniquePopover();

        this.jsonStringify = JSON.stringify;

        this.state = useState({'record_id': null});

        onWillStart(this.handleComponentUpdate.bind(this));
        onWillRender(this.handleComponentUpdate.bind(this));
        		
		this.fieldname = this.props.name;
		this.res_model = this.props.value.resModel;
		this.rec_name = this.props.rec_name;		
    }
    
    get context() {
		return _.extend({hierarchical_naming : false}, this.props.value.context, this.props.record.context);
	}

    /**
     * Called on start and on render
     */
    async handleComponentUpdate() {
        this.record = this.props.record.data;
        this.state.record_id = this.record.id;
        const forceReload = this.lastRecord !== this.props.record;
        this.lastRecord = this.props.record;
        await this.fetchRecordData(this.state.record_id, forceReload);
    }

    async fetchRecordData(recordId, force = false) {
        if (!recordId) {
            this.parents = [];
            this.children = [];
            if (this.view_record_id) {
                this.render(true);
            }
            this.view_record_id = null;
        } else if (recordId !== this.view_record_id || force) {
            this.view_record_id = recordId;
            var orgData = await this.rpc(
                '/org_chart/get_org_chart',
                {
                    record_id: recordId,
                    model: this.res_model,
                    fieldname: this.fieldname,
                    rec_name: this.rec_name,
                    context: this.context,
                }
            );
            if (Object.keys(orgData).length === 0) {
                orgData = {
                    parents: [],
                    children: [],
                }
            }
            this.parents = orgData.parents;
            this.children = orgData.children;
            this.parents_more = orgData.parents_more;
            this.self = orgData.self;
            this.render(true);
        }
    }

    _onOpenPopover(event, record) {
		const context = this.context;
		
        this.popover.add(
            event.currentTarget,
            this.constructor.components.Popover,
            {record, context},
            {closeOnClickAway: true}
        );
    }

    /**
     * Redirect to the record form view.
     *
     * @private
     * @param {MouseEvent} event
     * @returns {Promise} action loaded
     */
    async _onRecordRedirect(recordId) {
        const action = await this.orm.call(this.res_model, 'get_formview_action', [recordId], {context: this.context});
        this.actionService.doAction(action, {clearBreadcrumbs : this.props.clearBreadcrumbs}); 
    }

    async _onRecordMoreManager(parentId) {
        await this.fetchRecordData(parentId);
        this.state.record_id = parentId;
    }
}

OrgChart.components = {
    Popover: OrgChartPopover,
};

OrgChart.template = 'org_chart.org_chart';

OrgChart.extractProps = ({ attrs }) => {
    return {
        rec_name: attrs.options.rec_name || 'display_name',
        clearBreadcrumbs: attrs.options.clearBreadcrumbs || false
    };
};

registry.category("fields").add("org_chart", OrgChart);
